const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
const db = require('mysql2'); 
const port = 3001;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'register.html'));
});

app.get('/share-recipe', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'addrecipe.html'));
});

app.get('/about', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'about.html'));
});

app.get('/contact', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'contactus.html'));
});

app.get('/recipes', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'recipe.html'));
});

// Route to fetch and display recipes
app.get('/recipes', (req, res) => {
    const query = 'SELECT title, content FROM recipes';
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching recipes:', err);
            res.status(500).send('Error fetching recipes.');
            return;
        }
        res.render('recipes', { recipes: results });
    });
});

app.post('/api/recipes', (req, res) => {
    const { title, ingredients, instructions } = req.body;
    const query = 'INSERT INTO recipes (user_id, title, content) VALUES (?, ?, ?)';
    db.query(query, [1, title, `${ingredients}\n\n${instructions}`], (err, result) => {
        if (err) {
            console.error('Error inserting recipe:', err);
            res.status(500).send('Error inserting recipe.');
            return;
        }
        res.send('Recipe submitted successfully!');
    });
});

app.post('/submit-contact', (req, res) => {
    const { name, email, message } = req.body;
    const query = 'INSERT INTO comments (recipe_id, user_id, content) VALUES (?, ?, ?)';
    db.query(query, [1, 1, `${name}: ${message}`], (err, result) => {
        if (err) {
            console.error('Error inserting comment:', err);
            res.status(500).send('Error inserting comment.');
            return;
        }
        res.send('Message sent successfully!');
    });
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
