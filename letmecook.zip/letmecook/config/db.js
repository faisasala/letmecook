const mysql = require('mysql2');

const db = mysql.createConnection({
  host: 'db4free.net',
  user: 'faisal_23014921',
  password: 'letmecook',
  database: 'letmecook',

});

db.connect(err => {
  if (err) {
    console.error('Error connecting to the database:', err.stack);
    return;
  }
  console.log('Connected to the database.');
});

module.exports = db;
