-- Create the database if it doesn't exist
CREATE DATABASE IF NOT EXISTS `LETMECOOK`;

-- Select the database
USE `LETMECOOK`;

-- Create the users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(100) NOT NULL
);

-- Create the recipes table
CREATE TABLE recipes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    title VARCHAR(100) NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Create the comments table
CREATE TABLE comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    recipe_id INT,
    user_id INT,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (recipe_id) REFERENCES recipes(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Create the ratings table
CREATE TABLE ratings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    recipe_id INT,
    user_id INT,
    rating INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (recipe_id) REFERENCES recipes(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Insert sample data into users table
INSERT INTO users (username, email, password) VALUES
('john_doe', 'john@example.com', 'password123'),
('jane_doe', 'jane@example.com', 'password456'),
('alice', 'alice@example.com', 'password789'),
('bob', 'bob@example.com', 'password101'),
('charlie', 'charlie@example.com', 'password202');

-- Insert sample data into recipes table
INSERT INTO recipes (user_id, title, content) VALUES
(1, 'Spaghetti Bolognese', 'Cook spaghetti. Fry minced beef with onions and garlic. Add tomato sauce. Combine with spaghetti.'),
(2, 'Chicken Curry', 'Fry onions, garlic, and ginger. Add chicken and curry powder. Add coconut milk and simmer.'),
(3, 'Vegetable Stir Fry', 'Fry garlic and ginger. Add vegetables and soy sauce. Stir fry until cooked.'),
(4, 'Pancakes', 'Mix flour, eggs, milk, sugar, and baking powder. Cook on a griddle with butter.'),
(5, 'Caesar Salad', 'Mix lettuce, croutons, Caesar dressing, and parmesan cheese. Add grilled chicken.');

-- Insert sample data into comments table
INSERT INTO comments (recipe_id, user_id, content) VALUES
(1, 2, 'Delicious recipe! My family loved it.'),
(2, 1, 'Great taste! Will make it again.'),
(3, 4, 'Very easy and healthy.'),
(4, 5, 'Best pancakes I have ever made.'),
(5, 3, 'Simple and tasty.');

-- Insert sample data into ratings table
INSERT INTO ratings (recipe_id, user_id, rating) VALUES
(1, 3, 5),
(2, 4, 4),
(3, 5, 5),
(4, 2, 4),
(5, 1, 5);

-- Select data from the tables
SELECT * FROM users;
SELECT * FROM recipes;
SELECT * FROM comments;
SELECT * FROM ratings;
