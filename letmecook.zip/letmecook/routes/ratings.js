const express = require('express');
const router = express.Router();
const ratingsModel = require('../models/ratings');

// Add a rating
router.post('/add', async (req, res) => {
    const { recipeId, userId, rating } = req.body;
    try {
        await ratingsModel.addRating(recipeId, userId, rating);
        res.status(201).send('Rating added');
    } catch (err) {
        console.error('Error adding rating:', err);
        res.status(500).send('Error adding rating');
    }
});

// Get average rating for a recipe
router.get('/:recipeId', async (req, res) => {
    const { recipeId } = req.params;
    try {
        const result = await ratingsModel.getAverageRating(recipeId);
        res.status(200).json(result);
    } catch (err) {
        console.error('Error fetching rating:', err);
        res.status(500).send('Error fetching rating');
    }
});

module.exports = router;
