const express = require('express');
const router = express.Router();
const recipeModel = require('../models/recipe');

// Add a new recipe
router.post('/add', async (req, res) => {
    const { title, ingredients, instructions, image } = req.body;
    try {
        await recipeModel.createRecipe(title, ingredients, instructions, image);
        res.status(201).send('Recipe added');
    } catch (err) {
        console.error('Error adding recipe:', err);
        res.status(500).send('Error adding recipe');
    }
});

// Get all recipes
router.get('/', async (req, res) => {
    try {
        const recipes = await recipeModel.getAllRecipes();
        res.status(200).json(recipes);
    } catch (err) {
        console.error('Error fetching recipes:', err);
        res.status(500).send('Error fetching recipes');
    }
});

module.exports = router;
