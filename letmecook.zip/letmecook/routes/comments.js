const express = require('express');
const router = express.Router();
const commentsModel = require('../models/comments');

// Add a comment
router.post('/add', async (req, res) => {
    const { recipeId, userId, commentText } = req.body;
    try {
        await commentsModel.addComment(recipeId, userId, commentText);
        res.status(201).send('Comment added');
    } catch (err) {
        console.error('Error adding comment:', err);
        res.status(500).send('Error adding comment');
    }
});

// Get comments for a specific recipe
router.get('/:recipeId', async (req, res) => {
    const { recipeId } = req.params;
    try {
        const comments = await commentsModel.getCommentsByRecipeId(recipeId);
        res.status(200).json(comments);
    } catch (err) {
        console.error('Error fetching comments:', err);
        res.status(500).send('Error fetching comments');
    }
});

module.exports = router;
