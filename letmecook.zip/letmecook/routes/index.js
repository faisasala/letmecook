const express = require('express');
const router = express.Router();

const userRoutes = require('./userRoutes');
const recipeRoutes = require('./recipeRoutes');
const commentsRoutes = require('./comments');
const ratingsRoutes = require('./ratings');

// Use routes
router.use('/users', userRoutes);
router.use('/recipes', recipeRoutes);
router.use('/comments', commentsRoutes);
router.use('/ratings', ratingsRoutes);

module.exports = router;


