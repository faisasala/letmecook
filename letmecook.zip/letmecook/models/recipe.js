const pool = require('../config/db');

// Create a new recipe
async function createRecipe(title, ingredients, instructions, image) {
    const [result] = await pool.execute(
        'INSERT INTO recipes (title, ingredients, instructions, image) VALUES (?, ?, ?, ?)',
        [title, ingredients, instructions, image]
    );
    return result;
}

// Get all recipes
async function getAllRecipes() {
    const [rows] = await pool.execute('SELECT * FROM recipes');
    return rows;
}

module.exports = {
    createRecipe,
    getAllRecipes
};
