const pool = require('../config/db');

// Add a new comment
async function addComment(recipeId, userId, commentText) {
    const [result] = await pool.execute(
        'INSERT INTO comments (recipe_id, user_id, comment_text) VALUES (?, ?, ?)',
        [recipeId, userId, commentText]
    );
    return result;
}

// Get comments for a specific recipe
async function getCommentsByRecipeId(recipeId) {
    const [rows] = await pool.execute(
        'SELECT * FROM comments WHERE recipe_id = ?',
        [recipeId]
    );
    return rows;
}

module.exports = {
    addComment,
    getCommentsByRecipeId
};
