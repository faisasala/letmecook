const pool = require('../config/db');

// Create a new user
async function createUser(username, email, password) {
    const [result] = await pool.execute(
        'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
        [username, email, password]
    );
    return result;
}

// Find a user by email and password
async function findUserByEmailAndPassword(email, password) {
    const [rows] = await pool.execute(
        'SELECT * FROM users WHERE email = ? AND password = ?',
        [email, password]
    );
    return rows;
}

module.exports = {
    createUser,
    findUserByEmailAndPassword
};
