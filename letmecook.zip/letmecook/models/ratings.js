const pool = require('../config/db');

// Add a rating
async function addRating(recipeId, userId, rating) {
    const [result] = await pool.execute(
        'INSERT INTO ratings (recipe_id, user_id, rating) VALUES (?, ?, ?)',
        [recipeId, userId, rating]
    );
    return result;
}

// Get the average rating for a recipe
async function getAverageRating(recipeId) {
    const [rows] = await pool.execute(
        'SELECT AVG(rating) AS averageRating FROM ratings WHERE recipe_id = ?',
        [recipeId]
    );
    return rows[0]; // Return the first row, as it's the only one
}

module.exports = {
    addRating,
    getAverageRating
};
