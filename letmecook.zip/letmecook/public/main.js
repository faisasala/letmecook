document.addEventListener('DOMContentLoaded', function() {
    // Add JavaScript code for interactivity
    console.log("LetMeCook homepage loaded!");
});
